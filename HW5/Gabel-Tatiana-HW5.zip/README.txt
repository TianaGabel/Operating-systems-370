Process.h and Process.cpp is a class to represent a process as well as the amount of work that has been done
Scheduler includes the main method and runs all 3 scheduling algorithms based on a file name that has been passed as a commandline arguement
