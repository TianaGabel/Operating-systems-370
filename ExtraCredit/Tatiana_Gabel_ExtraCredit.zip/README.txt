Profiler.c takes in a pid as a commandline arg, then reads various information about process from files

make all can be used to compile
then "a.out <pid>" to run 
such as a.out $$ for bash