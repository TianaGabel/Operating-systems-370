Monitor Class:
This class acts as both a traditional monitor and my circular buffer

Consumer Class:
This is the consumer class according to the specifications

Producers Class:
This is the producer class according to the specifications

Main class:
This is where Monitor, Consumer and Producer are created and started if it is a thread.